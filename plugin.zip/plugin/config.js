const config = {
    API_ENDPOINT: 'http://localhost:3000'
}; 